function expectedladval  = expectedladr( mu0, P, m,r,numofgen  )
%function [g11, fitvecm,fitvecm2,expvar, expvar2, expmu]  = expectedladr( mu0, P, m,r,numofgen  )
% Input values: 
% mu0 - The fraction of one of the ancestral population in the admixture event
% P - The correlation between the ancestry of the mother and the father.
% m - a vector of length 2 representing the migration values from each of 
% the populations
% r - the recombination probability (a number between 0 and 0.5). 
% numofgen - the number of generations
% 
% Return value: The expected LAD value after numofgen generations under
% the input parameters.

lad0 = mu0*(1-mu0);
rho0 = P*lad0;
fitvecm(1) = lad0;
expvar(1) = lad0;
expvar2(1) = lad0;
fitvecm2(1) = lad0;
g11(1) = 0.5;
expmu(1) = 0.5;

epsilon = 0.0000001;
m = m + epsilon*rand(1,2);
alpha = m(1)/sum(m);
m = sum(m);

x0 = mu0-alpha;
%fprintf ('x0 = %f\n', x0);
q1 = (1+P)/2;
q2 = 1;
a0 = alpha*m*(1-alpha);
a1 = 0;
a2 = 0;
a3 = m*(1-m);
y0 = rho0/P;
[b0,b1,b2,b3,b4] = lemma32( a0,a1,a2,a3,q1,q2,m,x0,y0 );
%fprintf ('b0 = %f b3 = %f b4 = %f\n', b0, b3, b4);

for t=1:numofgen
    expvar(t+1) = b0 + b3*x0*power(1-m,t)*power(1+P,t)/power(2,t) + ...
        b4*x0*x0*power(1-m,2*t);
    q2 = (1+P)/2;
    xt = x0*power(1-m,t);
    expvar2(t+1) = m*(1-m)*xt*xt + alpha*m*(1-alpha) + expvar2(t)*(1-m)*(1+P)/2;
    q2t = power(q2,t);
    q1 =  1-r;
    a3 = ((1-m)*(1-m)*(m-r) + r + r*P*b4)/(1-m);
    a2 = 2*r*P*b3/(1+P);
    a1 = 2*alpha*r*m;
    a0 = alpha*m*(1-alpha) + (1-m)*r*P*b0;
    [c0,c1,c2,c3,c4] = lemma32( a0,a1,a2,a3,q1,q2,m,x0,lad0 );
    fitvecm(t+1) = c4*xt*xt + xt*(c3*power(q1,t) + c2*q2t + c1) + c0;

    if (t > 1)
        g11(t+1) = alpha*m + (1-m)*((1-r)*g11(t) + ...
            r*(alpha*alpha + P*expvar2(t-1)));
    else
        g11(t+1) = alpha*m + (1-m)*((1-r)*g11(t) + ...
            r*(alpha*alpha + rho0));
    end


  expmu(t+1) = xt+alpha;
  
  fitvecm2(t+1) = (1-m)*(1-r)*fitvecm2(t) + xt*xt*m*(1-m) + ...
      m*alpha*(1-alpha) + (1-m)*r*P*expvar2(t);
 
end

expectedladval = fitvecm2(numofgen+1);

end

