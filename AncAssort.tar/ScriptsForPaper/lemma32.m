function [b0,b1,b2,b3,b4] = lemma32( a0,a1,a2,a3,q1,q2,m,x0,y0 )
% Function [b0,b1,b2,b3,b4] = lemma32( a0,a1,a2,a3,q1,q2,m,x0,y0 )
% Provides the values calculated in Lemma 3.2 in the paper

b0 = a0/(1-(1-m)*q1);
b1 = a1/((1-m)*(1-q1));
b2 = a2/((1-m)*(q2-q1));
b4 = a3/((1-m)*(1-m-q1));
b3 = (y0-b4*x0*x0-(b1+b2)*x0-b0)/x0;

end

