function [gamma11, lad, globalanc, localanc, v,truemu] = simulatepairmigration( r,t,P,m1,m2 )
%function [gamma11, lad, globalanc, localanc, v,truemu] = simulatepairmigration( r,t,P,m1,m2 )
% Input parameters:
% r - the recombination probabilty
% t - the number of generations
% P - the correlation between the ancestry of the parents.
% m1 - Migration from Population 1
% m2 - Migration from Population 2
%
% Simulates a 10,000 population size
% gamma11 - The frequency of the haplotype 11 in each generation
% lad - the values gamma11-gamma0*gamma1 in each generation
% globalanc - The gloabl ancestry values in the last generation
% localanc - The local ancestry values in the last generation
% v - The variance of the global ancesty in each of the generations
% truemu - For each generation, the fraction of ancestry 1 in position 1
% and in position 2


n = 10000; % population size - hard coded
corrthresh = 0.01;
localanc = [ones(n/2,2);zeros(n/2,2)];
globalanc = [ones(n/2,1); zeros(n/2,1)];
alphaval = m1/(m1+m2);

for i=1:t
    %fprintf ('generation %d\n', i);
    g11 = sum(localanc(:,1).*localanc(:,2))/n;
    gamma11(i) = g11;
    g1 = [sum(localanc(:,1)), sum(localanc(:,2))]/n;
    truemu(i,:) = g1;
    lad(i) = g11-g1(1)*g1(2);
    u = 100;
    l = 0;
    c = -2*corrthresh;
    iter = 1;
    clist = c;
    while (abs(c-P) > corrthresh)
        iter = iter + 1;
        s = (u+l)/2;
        %fprintf ('c = %f s = %f P = %f iter = %d\n', c,s,P, iter);
        [motherstmp,idxm] = sort(globalanc + randn(n,1)*s);
        [fatherstmp,idxf] = sort(globalanc + randn(n,1)*s);
        c = corr(globalanc(idxf),globalanc(idxm));
        clist(iter) = c;
        if (c < P)
            u = s;
        else
            l = s;
        end   
        if (mod(iter,100) == 0)
            fprintf ('stuck with %d iterations\n', iter);
 %           figure;
 %           plot(clist);
 %           drawnow
        end
    end
    tmp = cov(globalanc(idxf),globalanc(idxm));
    v(i) = tmp(1,1);
    rec = rand(n,1) < r;
    migration1 = datasample(1:n, round((m1+m2)*n), 'Replace', false);
    if (m1 + m2 > 0)
        migration2 = datasample(migration1, round(m1*size(migration1,2)/(m1+m2)),...
            'Replace', false);
    else
        migration2 = datasample(migration1, 0,'Replace', false);
    end
    tmp = zeros(n,1);
    tmp(migration2) = 1;
    tmp2 = zeros(n,1);
    tmp2(migration1) = 1;
    migration1 = tmp;
    migration2 = tmp2-migration1;
    globalanc = (globalanc(idxf) + globalanc(idxm))/2;
    globalanc = migration1 + (1-migration1).*globalanc;
    globalanc = (1-migration2).*globalanc;
    tmp = m1;
    tmp = tmp - (m1+m2)*mean(globalanc)*mean(globalanc);
    tmp = tmp + (1-m1-m2)*(1+P)*v(i)/2;
    localanc = [localanc(idxf,1),(1-rec).*localanc(idxf,2) + rec.*localanc(idxm,2)];
    migration1 = migration1*[1 1];
    migration2 = migration2*[1 1];
    localanc = migration1 + (1-migration1).*localanc;
    localanc = (1-migration2).*localanc;
end
g11 = sum(localanc(:,1).*localanc(:,2))/n;
g1 = [sum(localanc(:,1)), sum(localanc(:,2))]/n;
truemu(t+1,:) = g1;
lad(t+1) = g11-g1(1)*g1(2);
v(t+1) = var(globalanc);
gamma11(t+1) = g11;
%fprintf('end\n');
%hist(globalanc,20);

end



